from rest_framework import serializers
from menu.models import *

class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields =['idUsuario','rut','nombre','apellido','telefono','fNacimiento','correo','clave','rol']
class RegionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Region
        fields = ['idRegion','nombre']
class VentaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Venta
        fields = ['idVenta','fVenta','total','fEntrega','despacho','carrito','direccion','usuario']
class ComunaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comuna
        fields = ["idCom","nombre","region"]
class DireccionSerialzer(serializers.ModelSerializer):
    class Meta:
        model = Direccion
        fields = ["idDireccion","calle","numero","comuna","usuario"]
class DetalleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Detalle
        fields = ["idDetalle","cantidad","subTotal","venta","producto"]