from django.urls import path, include
from .views import *
from .viewslogin import *

urlpatterns =[
    path('lista_reg/',lista_reg,name="lista_reg"),
    path('lista_usuario/',lista_usuario,name="lista_usuario"),
    path('detalle_usuario/<id>',detalle_usuario,name="detalle_usuario"),
    path('login',login,name="login"),
    path('venta',venta,name="venta"),
    path('comuna',comuna,name="comuna"),
    path('direccion',direccion,name="direccion"),
    path('detalle',detalle,name="detalle"),
]
