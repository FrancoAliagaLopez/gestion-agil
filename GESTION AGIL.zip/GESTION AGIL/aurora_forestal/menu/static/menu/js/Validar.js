$(document).ready(function () {
    $("#registro").submit(function (e) {
        
        var nombre=$("#nombre").val();
        var apellido=$("#apellido").val();
        var rut=$("#rut").val();
        var telefono=$("#telef").val();
        var correo=$("#email").val();
        var clave=$("#contra").val();
        var clave1=$("#contra1").val();

        var msjMostrar="";
        let enviar = false;

        if(nombre.trim().length < 4 || nombre.trim() >14){
            
            msjMotrar += "El nombre debe tener entre 4 y 14 caracteres";
            enviar = true;
        }
        if(apellido.trim().length < 4 || apellido.trim() >14){
            msjMotrar += "El apellido debe tener entre 4 y 14 caracteres";
            enviar = true;
        }
        if( isNaN(telefono) ){
            msjMotrar += "<br>El teléfono solo pueden ser números";
        }
        if(correo.trim().length == 0){
            mensaje = mensaje + "<br>El correo electrónico no puede estar vacío";
        }

        if(clave.trim().length < 8 || clave.trim().length > 16){
            msjMostrar += "La clave debe ser entre 8 a 16 caractéres";
            enviar=true;
        }
        var letra = clave.trim().charAt(0);
        if(!esMayuscula(letra)){
            msjMostrar += "<br>La primera letra debe ser mayúscula";
            enviar=true;
        }
        if(clave1 != clave1){
            msjMostrar += "La clave debe ser igual a la ingresada anteriormente";
            enviar = true;
        }
        if (enviar){
            e.preventDefault();
            $("#warnings").html(msjMostrar);
        }
        else{
            $("#warnings").html("Enviado");
        }
        
    });


    function esMayuscula(letra){
        if (letra == letra.toUpperCase()){
            return true;
        }
        else{
            return false;
        }
    }
});