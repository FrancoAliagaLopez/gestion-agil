$(document).ready(function () {
    $("#contacto").submit(function (e) {
        
        var nombre=$("#nombre").val();
        var apellido=$("#apellido").val();
        var telefono=$("#tel").val();
        var correo=$("#email").val();

        var msjMostrar="";
        let enviar = false;

        if(nombre.trim().length == 0){
            msjMotrar += "<br>El campo nombre no debe estar vacio";
            enviar = true;
        }
        if(apellido.trim().length == 0){
            msjMotrar += "<br>El campo apellido no debe estar vacio";
            enviar = true;
        }
        if( isNaN(telefono) ){
            msjMotrar += "<br>El teléfono solo pueden ser números";
        }

        if(correo.trim().length == 0){
            mensaje = mensaje + "<br>El correo electrónico no puede estar vacío";
        }


        if (enviar){
            e.preventDefault();
            $("#warnings").html(msjMostrar);
        }
        else{
            $("#warnings").html("Enviado");
        }
        
    });

});