import uuid
import requests
import json
from django.shortcuts import render,redirect
from menu.carrito import Carrito
from .models import *
from django.contrib import messages
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.hashers import check_password
from django.contrib.auth import authenticate,login, logout
from django.http import HttpResponse
# Create your views here.

def vuelta(request):
    token_ws = request.GET.get('token_ws')
    if not token_ws:
        return render(request, 'menu/error.html', {'message': 'Token no encontrado'})

    headers = {
        "Tbk-Api-Key-Id": "597055555532",
        "Tbk-Api-Key-Secret": "579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C",
        "Content-Type": "application/json"
    }
    url_servicio = f'https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions/{token_ws}'
    respuesta = requests.put(url_servicio, headers=headers)
    respuesta_data = respuesta.json()

    if respuesta_data.get('status') == 'AUTHORIZED':
        messages.success(request, 'Compra exitosa')
        return redirect('vuelta')
    else:
        return render(request, 'menu/error.html', {'message': 'Transacción no autorizada', 'response': respuesta_data})
    

def webpay(orderCompra, sesion, monto):
    headers = {
        "Tbk-Api-Key-Id": "597055555532",
        "Tbk-Api-Key-Secret": "579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C",
        "Content-Type": "application/json"
    }
    data = {
        "buy_order": orderCompra,
        "session_id": sesion,
        "amount": float(monto),
        "return_url": "http://127.0.0.1:8000/vuelta/"  # Asegúrate de que el puerto es el correcto
    }
    print(data)
    url_servicio = 'https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions'
    respuesta = requests.post(url_servicio, data=json.dumps(data), headers=headers)
    return respuesta.json()

def pagar(request, id):
    venta = Venta.objects.get(idVenta=id)
    orderCompra = "aa123"  
    sesion = "aa2222"  
    monto = venta.total
    resp = webpay(orderCompra, sesion, monto)  
    url = resp['url']
    token = resp['token']
    contexto = {
        "venta": venta,
        "url": url,
        "token": token,
    }
    return render(request, 'menu/pago.html', contexto)

def plantas_interior(request):
    listaP = Producto.objects.all()
    contexto ={
        "productos" : listaP
    }
    return render(request,'menu/plantas_dentro.html',contexto)
def plantas_fuera(request):
    tipo = Tipo.objects.all()
    listaP = Producto.objects.all()
    contexto ={
        "productos" : listaP,
        "tipos" : tipo
    }
    return render(request,'menu/plantas_exterior.html',contexto) 
def productos(request):
    listaP = Producto.objects.all()
    contexto ={
        "productos" : listaP
    }
    return render(request,'menu/producto_cuidado.html',contexto)
def index(request):
    return render(request, 'menu/index.html')
def contacto(request):
    return render(request, 'menu/contacto.html')
def inicio_sesion(request):
    return render(request,'menu/inicio_sesion.html')
def incio_usu(request):
    usuario1 = request.POST['correo']
    clave1 = request.POST['clave']
    try:
        user1 = User.objects.get(username = usuario1)
    except User.DoesNotExist:
        messages.error(request,'El usuario o contraseña son incorrectos')
        return redirect('inicio')

    pass_valida = check_password(clave1 , user1.password)
    if not pass_valida:
        messages.error(request, 'El usuario o la contraseña son incorrectos')
        return redirect('inicio')
    usuario2 = Usuario.objects.get(correo = user1, clave = clave1)
    user = authenticate(username = usuario1, password = clave1)
    if user is not None:
        login(request,user)
        if(usuario2.rol.idRol == 2):
            return redirect('listarPro')
        else:
            contexto = {"usuario":usuario2,
                        }
            return render(request, 'menu/index.html',contexto)
        


def cerrar_sesion(request):
    logout(request)
    return render(request, "menu/index.html")
def perfil(request):
    user = request.user
    if user.is_authenticated:
        usuario = Usuario.objects.all()
        direccion = Direccion.objects.all()
        contexto ={
            "cuenta" : usuario,
            "direccion" : direccion
        }
        return render(request, 'menu/perfil.html', contexto)
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")
    
def modificarPerfil(request,id):
    if request.user.is_authenticated:
        usuario = Usuario.objects.get(idUsuario = id)
        contexto = {
            "cuenta": usuario
        }
        return render(request,'menu/modificar_datos.html',contexto)
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")
    
def cambioContra(request,id):
    if request.user.is_authenticated:
        usuario = Usuario.objects.get(idUsuario = id)
        contexto={
            "cuenta":usuario
        }
        return render(request,'menu/cambio_contra.html',contexto)
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")


def actualizarPerfil(request):
    if request.user.is_authenticated:
        user = request.user
        nombre = request.POST['nombre']
        apellido = request.POST['apellido']
        telefono = request.POST['telefono']
        email = request.POST['email']
        cuenta = Usuario.objects.get(idUsuario = user.id)
        cuenta.nombre = nombre
        cuenta.apellido = apellido
        cuenta.telefono = telefono
        cuenta.correo = email
        user.email = email
        user.username = email
        user.save()
        cuenta.save()
        messages.success(request,"Perfil modificado correctamente")
        return redirect('perfil')
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")
    
def agregarDir(request):
    if request.user.is_authenticated:
        datoRegion = Region.objects.all()
        datoComuna = Comuna.objects.all()
        contexto = {
            "region" : datoRegion,
            "comuna" : datoComuna
        }
        return render(request,'menu/agregar_dir.html',contexto)
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")

def eliminarDir(request,id):
    if request.user.is_authenticated:
        direccion = Direccion.objects.get(idDireccion = id)
        direccion.delete()
        messages.success(request,"Direccion eliminada correctamente")
        return redirect('perfil')
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")

def modificarDir(request,id):
    if request.user.is_authenticated:
        direccion = Direccion.objects.get(idDireccion = id)
        comuna = Comuna.objects.all()
        region = Region.objects.all()
        contexto = {
            "direccion" : direccion,
            "comuna" : comuna,
            "region" : region
        }
        return render(request,'menu/modificar_direccion.html',contexto)
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")
    
def actualizarDir(request,id):
    if request.user.is_authenticated:
        calle = request.POST['calle']
        numero = request.POST['numero']
        region = request.POST['region']
        comuna = request.POST['comuna']
        direccion = Direccion.objects.get(idDireccion = id)
        registroComuna = Comuna.objects.get(idCom = comuna)
        direccion.calle = calle
        direccion.numero = numero
        direccion.comuna = registroComuna
        direccion.save()
        messages.success(request,"Direccion modificada correctamente")
        return redirect('perfil')
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")

def guardarDir(request):
    if request.user.is_authenticated:
        user = request.user
        calle = request.POST['calle']
        numero = request.POST['numero']
        region = request.POST['region'] 
        comuna = request.POST['comuna'] 
        idUsuario = Usuario.objects.get(idUsuario=user.id)
        registroReg = Region.objects.get(idRegion = region)
        registroCom = Comuna.objects.get(idCom = comuna)
        Direccion.objects.create(calle = calle, numero = numero,
                                comuna =registroCom, usuario = idUsuario)
        return redirect('perfil')
    else:
        return HttpResponse("ERROR, DEBES INICIAR SESION")
    
def nosotros(request):
    return render(request, 'menu/nosotros.html')
def registro(request):
    return render(request, 'menu/registro.html')
def carrito(request):
    productos = Producto.objects.all()
    contexto={
        "productos":productos
    }
    return render(request,'menu/carrito.html',contexto)

def agregar_producto(request,producto):
    carrito= Carrito(request)
    producto = Producto.objects.get(idProducto = producto)
    carrito.agregar(producto)
    messages.success(request,"Producto añadido correctamente")
    return redirect('plantas_interior')

def agregar_producto1(request,producto):
    carrito= Carrito(request)
    producto = Producto.objects.get(idProducto = producto)
    carrito.agregar(producto)
    messages.success(request,"Producto añadido correctamente")
    return redirect('venta1')

def agregar_producto2(request,producto):
    carrito= Carrito(request)
    producto = Producto.objects.get(idProducto = producto)
    carrito.agregar(producto)
    messages.success(request,"Producto añadido correctamente")
    return redirect('venta2')

def agregar_producto3(request,producto):
    carrito= Carrito(request)
    producto = Producto.objects.get(idProducto = producto)
    carrito.agregar(producto)
    messages.success(request,"Producto añadido correctamente")
    return redirect('carrito')


def eliminar_producto(request,producto):
    carrito = Carrito(request)
    producto = Producto.objects.get(idProducto = producto)
    carrito.eliminar(producto)
    return redirect('carrito')

def restar_producto(request,producto):
    carrito = Carrito(request)
    producto = Producto.objects.get(idProducto = producto)
    carrito.restar(producto)
    return redirect('carrito')

def limpiar_carrito(request):
    carrito = Carrito(request)
    carrito.limpiar_carrito()
    return redirect('carrito')

def recuperacion(request):
    return render(request,'menu/recuperacion_de_clave.html')
def recuperacion1(request):
    return render(request,'menu/recuperacion_siguiente.html')
def api1(request):
    return render(request,'menu/api1.html')


def insertarVenta(request):
    venta_id = uuid.uuid4().hex
    precio = request.POST['acumulado']
    Venta.objects.create(idVenta=venta_id,total = precio)
    return redirect('pagar',id=venta_id)

def crearUsuario(request):
    nom = request.POST['nombre']
    ape = request.POST['apellido']
    run = request.POST['rut']
    tel = request.POST['telef']
    fec = request.POST ['fec']
    cor = request.POST['email']
    clave = request.POST['contra']

    rol1 = Rol.objects.get(idRol = 1)
    Usuario.objects.create(rut = run,nombre = nom, apellido = ape,
                           telefono = tel,fNacimiento = fec,correo = cor,
                           clave = clave, rol = rol1)

    user = User.objects.create_user(username= cor,
                                    email= cor,
                                    password= clave)
    user.is_active = True
    user.save()
    return redirect('inicio')


def listarPro(request):
    if request.user.is_authenticated and request.user.is_staff:
        listaP = Producto.objects.all()
        contexto = {
            "productos" : listaP
        }
        return render(request, 'menu/listar_pro.html', contexto)
    else:
        return HttpResponse("ACCESO DENEGADO")
    

def agregarPro(request):
    if request.user.is_authenticated and request.user.is_staff:
        datoTipo = Tipo.objects.all()
        datoCat = Categoria.objects.all()
        contexto = {
            "tipo" : datoTipo,
            "categoria" : datoCat
        }
        return render (request,'menu/agregar_pro.html',contexto)
    else:
        return HttpResponse("ACCESO DENEGADO")


def insertarPro(request):
    if request.user.is_authenticated and request.user.is_staff:
        idPro = request.POST['idpro']
        nombrePro = request.POST['nombre']
        descripcionPro = request.POST['desc']
        stockPro =  request.POST['stock']
        precioPro =  request.POST['precio']
        fotoPro =  request.FILES['foto']
        tipoPro = request.POST['tipo']
        categoriaPro = request.POST['categoria']

        registroCat = Categoria.objects.get(idCategoria = categoriaPro)
        registroTipo =  Tipo.objects.get(idTipo = tipoPro)
        Producto.objects.create(idProducto = idPro, nombre = nombrePro, 
                            descripcion = descripcionPro, stock = stockPro,
                            precio = precioPro, foto = fotoPro,
                            categoria = registroCat, tipo = registroTipo)
        messages.success(request,"Producto agregado correctamente")
        return redirect('listarPro')
    else:
        return HttpResponse("ACCESO DENEGADO")

def eliminarPro(request,id):
    if request.user.is_authenticated and request.user.is_staff:
        producto = Producto.objects.get(idProducto = id)
        producto.delete()
        messages.success(request,"Producto eliminado correctamente")
        return redirect('listarPro')
    else:
        return HttpResponse("ACCESO DENEGADO")

def modificarPro(request,id):
    if request.user.is_authenticated and request.user.is_staff:
        producto = Producto.objects.get(idProducto = id)
        tipo = Tipo.objects.all()
        categoria = Categoria.objects.all()
        contexto = {
            "datos" : producto,
            "tipos" : tipo,
            "categorias" : categoria
        }
        return render(request,'menu/modificar_pro.html',contexto)
    else:
        return HttpResponse("ACCESO DENEGADO")

def actualizarPro(request):
    if request.user.is_authenticated and request.user.is_staff:
        idPro = request.POST['idpro']
        nom = request.POST['nombre']
        desc = request.POST['desc']
        sto = request.POST['stock']
        pre = request.POST['precio']
        fot = request.FILES['foto']
        tip = request.POST['tipo']
        cat = request.POST['categoria']

        producto = Producto.objects.get(idProducto = idPro)
        producto.nombre = nom
        producto.descripcion = desc
        producto.stock = sto
        producto.precio = pre
        producto.foto = fot
    
        registroTipo = Tipo.objects.get(idTipo = tip)
        producto.tipo = registroTipo
        registroCategoria = Categoria.objects.get(idCategoria = cat)
        producto.categoria = registroCategoria
        producto.save()
        messages.success(request,"Producto modificado correctamente")
        return redirect('listarPro')
    else:
        return HttpResponse("ACCESO DENEGADO")


