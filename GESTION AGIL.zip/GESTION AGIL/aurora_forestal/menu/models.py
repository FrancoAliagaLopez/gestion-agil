import uuid
from django.db import models
# Create your models here.
class Region(models.Model):
    idRegion = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100, null=False, blank=False)
    def __str__(self) -> str:
        return self.nombre

class Comuna(models.Model):
    idCom = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100,null=False,blank=False)
    region = models.ForeignKey(Region,on_delete=models.DO_NOTHING)
    def __str__(self) -> str:
        return self.nombre

class Rol(models.Model):
    idRol = models.AutoField(primary_key=True,verbose_name='Id del rol')
    nombre = models.CharField(max_length=50, null=False,blank=False)
    def __str__(self) -> str:
        return self.nombre

class Usuario(models.Model):
    idUsuario =models.AutoField(primary_key=True,verbose_name='Id del usuario')
    rut = models.CharField(max_length=13,null=False, blank=False)
    nombre = models.CharField(max_length=15,null=False, blank=False)
    apellido = models.CharField(max_length=20, null=False, blank=False)
    telefono = models.CharField(max_length=15,null=False, blank=False)
    fNacimiento = models.DateField(null=False, blank=False)
    correo = models.EmailField(max_length=254,null=False, blank=False)
    clave = models.CharField(max_length=12,null=False,blank=False)
    rol = models.ForeignKey(Rol, on_delete=models.DO_NOTHING)
    def __str__(self) -> str:
        return self.rut

class Direccion(models.Model):
    idDireccion = models.AutoField(primary_key=True,verbose_name='Id de la direccion')
    calle = models.CharField(max_length=50,null=False,blank=False)
    numero = models.CharField(max_length=6,null=False,blank=False)
    comuna = models.ForeignKey(Comuna, on_delete=models.DO_NOTHING)
    usuario = models.ForeignKey(Usuario, on_delete=models.DO_NOTHING)

class Venta(models.Model):
    idVenta = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    total = models.DecimalField(max_digits=10, decimal_places=2)

class Categoria(models.Model):
    idCategoria = models.AutoField(primary_key=True,verbose_name='Id de categoria')
    nombreCat = models.CharField(max_length=40,null=False, blank=False)
    def __str__(self) -> str:
        return self.nombreCat

class Tipo(models.Model):
    idTipo = models.AutoField(primary_key=True,verbose_name='Id de categoria')
    nombreTipo = models.CharField(max_length=40,null=False, blank=False)
    def __str__(self) -> str:
        return self.nombreTipo

class Producto(models.Model):
    idProducto = models.CharField(primary_key=True,verbose_name='Id de producto',max_length=50)
    nombre = models.CharField(max_length=20,null=False, blank=False)
    descripcion = models.CharField(max_length=254,null=False, blank=False)
    stock = models.IntegerField(null=False, blank=False)
    precio = models.IntegerField(null=False, blank=False)
    foto = models.ImageField(upload_to="")
    categoria = models.ForeignKey(Categoria,on_delete=models.DO_NOTHING)
    tipo = models.ForeignKey(Tipo,on_delete=models.DO_NOTHING)
    def __str__(self) -> str:
        return self.nombre

class Detalle(models.Model):
    idDetalle = models.AutoField(primary_key=True,verbose_name='Id de detalle venta')
    cantidad = models.IntegerField(null=False,blank=False)
    subTotal= models.IntegerField(null=False,blank=False)
    venta = models.ForeignKey(Venta,on_delete=models.DO_NOTHING)
    producto = models.ForeignKey(Producto, on_delete=models.DO_NOTHING)

